import React, {useState} from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  Image,
  Alert,
  TouchableOpacity,
  Platform,
  Text,
} from 'react-native';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import {Dropdown} from 'react-native-element-dropdown';
import DateTimePicker from '@react-native-community/datetimepicker';
import {images} from '../../assets';
import CustomHeader from '../../components/customHeader/CustomHeader';
import {moderateScale, scale, verticalScale} from '../../utils/responsive';
import {request, PERMISSIONS, RESULTS} from 'react-native-permissions';

const options = [
  {label: 'Male', value: 'Male'},
  {label: 'Female', value: 'Female'},
];

const AccountScreen = () => {
  const [selectedValue, setSelectedValue] = useState('');
  const [date, setDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [textInputValue, setTextInputValue] = useState('');

  const requestCameraPermission = async () => {
    try {
      const result = await request(
        Platform.OS === 'ios'
          ? PERMISSIONS.IOS.CAMERA
          : PERMISSIONS.ANDROID.CAMERA,
      );
      return result;
    } catch (error) {
      console.error('Failed to request camera permission', error);
    }
  };

  const requestGalleryPermission = async () => {
    try {
      const result = await request(
        Platform.OS === 'ios'
          ? PERMISSIONS.IOS.PHOTO_LIBRARY
          : PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE,
      );
      return result;
    } catch (error) {
      console.error('Failed to request gallery permission', error);
    }
  };

  const handleImagePick = async (type: 'camera' | 'gallery') => {
    const options = {
      mediaType: 'photo',
      includeBase64: false,
    };

    let permissionResult;
    if (type === 'camera') {
      permissionResult = await requestCameraPermission();
    } else {
      permissionResult = await requestGalleryPermission();
    }

    if (permissionResult === RESULTS.GRANTED) {
      const callback = (response: any) => {
        if (response.didCancel) {
          console.log('User cancelled image picker');
        } else if (response.errorCode) {
          console.log('ImagePicker Error: ', response.errorCode);
        } else {
          setImageUri(response.assets[0].uri);
        }
      };

      if (type === 'camera') {
        launchCamera(options, callback);
      } else {
        launchImageLibrary(options, callback);
      }
    } else {
      Alert.alert(
        'Permission Denied',
        'You need to grant permission to access this feature.',
      );
    }
  };

  const showImagePickerOptions = () => {
    Alert.alert(
      'Select Image Source',
      'Choose an option to select an image',
      [
        {
          text: 'Camera',
          onPress: () => handleImagePick('camera'),
        },
        {
          text: 'Gallery',
          onPress: () => handleImagePick('gallery'),
        },
        {
          text: 'Cancel',
          style: 'cancel',
        },
      ],
      {cancelable: true},
    );
  };

  const handleDateChange = (event: any, selectedDate: Date | undefined) => {
    if (Platform.OS === 'android') {
      setShowDatePicker(false);
    }
    if (selectedDate) {
      setDate(selectedDate);
    }
  };

  const handleTimeChange = (event: any, selectedTime: Date | undefined) => {
    if (Platform.OS === 'android') {
      setShowTimePicker(false);
    }
    if (selectedTime) {
      setDate(prevDate => {
        const newDate = new Date(prevDate);
        newDate.setHours(selectedTime.getHours());
        newDate.setMinutes(selectedTime.getMinutes());
        return newDate;
      });
    }
  };

  const handleSubmit = () => {
    Alert.alert(
      'Form Submitted',
      `Text: ${textInputValue}\nSelected: ${selectedValue}\nDate: ${date.toLocaleDateString()}\nTime: ${date.toLocaleTimeString()}`,
    );
  };

  const onPressNotification = () => {};

  return (
    <View style={styles.container}>
      <CustomHeader title="Account" onPressNotification={onPressNotification} />

      <View style={styles.userDetailContainer}>
        <View style={styles.userDetailInnerView}>
          <TouchableOpacity onPress={showImagePickerOptions}>
            <Image
              source={imageUri ? {uri: imageUri} : images.blank_profile}
              style={styles.profileContainer}
            />
          </TouchableOpacity>
          <View style={styles.nameContainer}>
            <TextInput
              style={styles.input}
              placeholder="Enter text"
              value={textInputValue}
              onChangeText={setTextInputValue}
            />

            <Dropdown
              style={styles.dropdown}
              data={options}
              labelField="label"
              valueField="value"
              placeholder="Select Gender"
              value={selectedValue}
              onChange={item => setSelectedValue(item.value)}
            />
          </View>
        </View>
        <TouchableOpacity
          style={styles.datePickerButton}
          onPress={() => setShowDatePicker(true)}>
          <Text>{date.toLocaleDateString()}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.timePickerButton}
          onPress={() => setShowTimePicker(true)}>
          <Text>{date.toLocaleTimeString()}</Text>
        </TouchableOpacity>

        {showDatePicker && (
          <DateTimePicker
            value={date}
            mode="date"
            display="default"
            onChange={handleDateChange}
            maximumDate={new Date()}
          />
        )}

        {showTimePicker && (
          <DateTimePicker
            value={date}
            mode="time"
            display="default"
            onChange={handleTimeChange}
          />
        )}
      </View>
    </View>
  );
};

export default AccountScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  userDetailContainer: {
    padding: scale(10),
  },
  userDetailInnerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  profileContainer: {
    height: 150,
    width: 150,
    borderRadius: moderateScale(10),
  },
  nameContainer: {
    flex: 1,
    flexDirection: 'column',
    paddingHorizontal: scale(20),
    borderRadius: scale(20),
  },
  input: {
    width: '100%',
    height: verticalScale(40),
    borderRadius: scale(7),
    borderColor: 'gray',
    borderWidth: 1,
    marginTop: verticalScale(10),
    paddingHorizontal: scale(10),
  },
  dropdown: {
    width: '100%',
    height: verticalScale(40),
    borderRadius: scale(7),
    borderColor: 'gray',
    borderWidth: 1,
    marginTop: verticalScale(10),
    paddingHorizontal: scale(10),
  },
  datePickerButton: {
    width: '100%',
    height: verticalScale(40),
    borderRadius: scale(7),
    borderColor: 'gray',
    borderWidth: 1,
    marginTop: verticalScale(10),
    justifyContent: 'center',
    paddingHorizontal: scale(10),
  },
  timePickerButton: {
    width: '100%',
    height: verticalScale(40),
    borderRadius: scale(7),
    borderColor: 'gray',
    borderWidth: 1,
    marginTop: verticalScale(10),
    justifyContent: 'center',
    paddingHorizontal: scale(10),
  },
  datePickerButtonText: {
    fontSize: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginTop: 10,
  },
  image: {
    width: 200,
    height: 200,
    marginTop: 20,
    resizeMode: 'cover',
  },
});

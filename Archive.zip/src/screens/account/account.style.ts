import {StyleSheet} from 'react-native';
import {scale, verticalScale, moderateScale} from '../../utils/responsive';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: moderateScale(20),
    backgroundColor: '#f8f8f8',
  },
  title: {
    fontSize: moderateScale(24),
    fontWeight: 'bold',
    marginBottom: verticalScale(20),
  },
  input: {
    height: verticalScale(40),
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: verticalScale(20),
    paddingHorizontal: scale(10),
    borderRadius: scale(5),
    backgroundColor: '#fff',
  },
  picker: {
    height: verticalScale(50),
    width: '100%',
    marginBottom: verticalScale(20),
  },
  image: {
    width: scale(200),
    height: scale(200),
    marginTop: verticalScale(20),
    alignSelf: 'center',
  },
});

export default styles;
